# jquery.mb.YTPlayer

__An open source jQuery component to easily build your custom Youtube® player or to use a Youtube® video as background for your page.__

[![](https://data.jsdelivr.com/v1/package/npm/jquery.mb.ytplayer/badge)](https://www.jsdelivr.com/package/npm/jquery.mb.ytplayer)

![mb.YTPlayer](http://pupunzi.open-lab.com/wp-content/uploads/2010/06/DSC03762.jpg)

## [go to the demo](https://pupunzi.com/#mb.components/mb.YTPlayer/YTPlayer.html)
## [go to the doc](https://github.com/pupunzi/jquery.mb.YTPlayer/wiki)
## [go to the blog](https://pupunzi.open-lab.com/mb-jquery-components/jquery-mb-YTPlayer/)


[jquery.mb.components](https://pupunzi.com/), another way of thinking the web


## Now available also for **Vimeo**: 
https://github.com/pupunzi/jQuery.mb.vimeo_player
